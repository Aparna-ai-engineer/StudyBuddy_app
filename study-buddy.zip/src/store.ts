import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type GradeLevel = 'KG' | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | '11' | '12';

export interface UserProfile {
  name: string;
  gradeLevel: GradeLevel;
  subjects: string[];
  xp: number;
  streak: number;
  badges: string[];
}

interface AppState {
  user: UserProfile | null;
  isOnboarded: boolean;
  setUser: (user: UserProfile) => void;
  updateUser: (updates: Partial<UserProfile>) => void;
  addXp: (amount: number) => void;
  addBadge: (badge: string) => void;
  resetOnboarding: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      isOnboarded: false,
      setUser: (user) => set({ user, isOnboarded: true }),
      updateUser: (updates) => set((state) => ({ user: state.user ? { ...state.user, ...updates } : null })),
      addXp: (amount) => set((state) => ({ user: state.user ? { ...state.user, xp: state.user.xp + amount } : null })),
      addBadge: (badge) => set((state) => ({ 
        user: state.user && !state.user.badges.includes(badge) 
          ? { ...state.user, badges: [...state.user.badges, badge] } 
          : state.user 
      })),
      resetOnboarding: () => set({ user: null, isOnboarded: false }),
    }),
    {
      name: 'studybuddy-storage',
    }
  )
);
