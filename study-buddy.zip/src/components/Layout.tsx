import React from 'react';
import { useStore } from '../store';
import { cn } from '../lib/utils';
import { Home, BookOpen, MessageCircle, MoreHorizontal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LayoutProps {
  children: React.ReactNode;
  currentScreen: string;
  onNavigate: (screen: any) => void;
}

export default function Layout({ children, currentScreen, onNavigate }: LayoutProps) {
  const { user, resetOnboarding } = useStore();
  
  if (!user) return null;

  // Determine theme based on grade
  const isYoung = ['KG', '1', '2', '3', '4', '5'].includes(user.gradeLevel);
  
  const themeClasses = isYoung 
    ? "bg-amber-50 text-slate-800" // Playful bright 
    : "bg-[#FDFBF7] text-[#2C2A29]"; // Premium sand & brown

  const headerTheme = isYoung
    ? "bg-orange-400 text-white"
    : "bg-[#3D332D] text-[#EFEAE2]";

  return (
    <div className={cn("min-h-screen flex flex-col font-sans", themeClasses)}>
      {/* Header */}
      <header className={cn("px-4 py-3 sm:py-4 flex items-center justify-between shadow-sm sticky top-0 z-20", headerTheme)}>
        <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-lg">
                SB
            </div>
            <h1 className="font-bold text-xl tracking-tight">StudyBuddy</h1>
        </div>
        <div className="flex items-center gap-3">
            <div className="text-sm font-medium flex items-center gap-1 bg-black/10 px-2 py-1 rounded-full">
               🔥 {user.streak}
            </div>
            <div className="text-sm font-medium flex items-center gap-1 bg-black/10 px-2 py-1 rounded-full">
               ⭐ {user.xp} XP
            </div>
            <button onClick={resetOnboarding} className="text-xs focus:outline-none opacity-80 hover:opacity-100">
               Logout
            </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-5xl mx-auto p-4 sm:p-6 pb-24 relative overflow-hidden">
        <AnimatePresence mode="wait">
            <motion.div
                key={currentScreen}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="h-full"
            >
                {children}
            </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Nav / Sidebar substitute for small app */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-black/5 shadow-[0_-4px_20px_rgba(0,0,0,0.05)] pb-safe z-30">
          <div className="max-w-md mx-auto flex justify-around p-3">
              <NavItem 
                icon={<Home size={24} />} 
                label="Home" 
                isActive={currentScreen === 'dashboard'} 
                onClick={() => onNavigate('dashboard')} 
                activeColor={isYoung ? "text-orange-500" : "text-[#8C6B52]"}
              />
              <NavItem 
                icon={<MessageCircle size={24} />} 
                label="AI Tutor" 
                isActive={currentScreen === 'doubt'} 
                onClick={() => onNavigate('doubt')} 
                activeColor={isYoung ? "text-orange-500" : "text-[#8C6B52]"}
              />
              <NavItem 
                icon={<BookOpen size={24} />} 
                label="Quiz" 
                isActive={currentScreen === 'quiz'} 
                onClick={() => onNavigate('quiz')} 
                activeColor={isYoung ? "text-orange-500" : "text-[#8C6B52]"}
              />
          </div>
      </nav>
    </div>
  );
}

function NavItem({ icon, label, isActive, onClick, activeColor }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void, activeColor: string }) {
    return (
        <button 
            onClick={onClick}
            className={cn(
                "flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-200 w-16",
                isActive ? activeColor : "text-gray-400 hover:text-gray-600"
            )}
        >
            <motion.div whileTap={{ scale: 0.9 }} animate={{ y: isActive ? -2 : 0 }}>
                {icon}
            </motion.div>
            <span className="text-[10px] sm:text-xs font-medium mt-1">{label}</span>
        </button>
    )
}
