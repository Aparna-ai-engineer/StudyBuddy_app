import React, { useState } from 'react';
import { useStore } from '../../store';
import { GoogleGenAI } from '@google/genai';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Image as ImageIcon, Sparkles, Loader2, Download } from 'lucide-react';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function ImageGeneratorMode({ onBack }: { onBack: () => void }) {
  const { user, addXp } = useStore();
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{imageUrl: string, explanation: string} | null>(null);

  const gradeLevel = user?.gradeLevel || '5';

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setResult(null);

    const prompt = `I am a student in grade ${gradeLevel}. I want to see an educational image about "${topic}".
First, generate a highly descriptive text-to-image prompt (max 50 words) that describes a clear, safe, educational, and colorful 3D style illustration of this topic.
Second, provide a very short, friendly explanation (max 2 sentences) of this topic.

Return ONLY a valid JSON object:
{
    "imagePrompt": "the descriptive prompt",
    "explanation": "the short explanation"
}`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        
        if (response.text) {
             const data = JSON.parse(response.text);
             const encodedPrompt = encodeURIComponent(data.imagePrompt + ', educational, textbook illustration, safe for kids, 3d style, clean, vibrant');
             const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?nologo=true&seed=${Math.floor(Math.random()*1000)}`;
             
             setResult({
                 imageUrl,
                 explanation: data.explanation
             });
             addXp(5);
        } else {
             throw new Error("No data returned");
        }
    } catch (e) {
        alert("Couldn't generate the image right now. Please try again!");
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full pb-10">
      <div className="flex items-center gap-4 mb-6">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors">
              <ArrowLeft size={20} className="text-gray-600"/>
          </button>
          <h2 className="text-xl font-bold flex items-center gap-2">
              <ImageIcon className="text-indigo-500" /> Visualizer
          </h2>
      </div>

      <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 p-6 sm:p-10 flex flex-col items-center">
          <div className="w-full max-w-lg mb-8 relative">
              <input 
                  type="text" 
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleGenerate()}
                  placeholder="e.g. A volcano erupting, Water cycle"
                  className="w-full text-lg px-6 py-4 pl-14 rounded-2xl border-2 border-indigo-100 focus:border-indigo-500 outline-none transition-all bg-indigo-50/30"
              />
              <ImageIcon className="absolute left-5 top-5 text-indigo-400" size={24} />
              
              <button 
                  onClick={handleGenerate}
                  disabled={loading || !topic.trim()}
                  className="absolute right-3 top-3 bottom-3 px-6 bg-indigo-500 text-white font-bold rounded-xl shadow-sm hover:bg-indigo-600 disabled:opacity-50 transition-colors"
              >
                  {loading ? <Loader2 size={20} className="animate-spin" /> : "Visualize"}
              </button>
          </div>

          <AnimatePresence mode="wait">
              {result && (
                  <motion.div 
                      key={topic}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="w-full max-w-lg"
                  >
                      <div className="rounded-3xl overflow-hidden bg-gray-100 mb-6 border-4 border-indigo-50 shadow-md relative aspect-square">
                          {/* Image */}
                          <img 
                              src={result.imageUrl} 
                              alt={topic} 
                              className="w-full h-full object-cover"
                              onLoad={(e) => (e.target as HTMLElement).style.opacity = '1'}
                              style={{ opacity: 0, transition: 'opacity 0.5s' }}
                          />
                          <div className="absolute inset-0 flex items-center justify-center font-medium text-gray-400 -z-10">
                              <Loader2 className="animate-spin mb-2" />
                          </div>
                      </div>
                      
                      <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 relative">
                          <Sparkles className="absolute -top-3 -left-3 text-indigo-400 bg-white rounded-full p-1" size={28} />
                          <h4 className="font-bold text-indigo-900 mb-2">Did you know?</h4>
                          <p className="text-indigo-800 leading-relaxed text-sm sm:text-base font-medium">{result.explanation}</p>
                      </div>
                  </motion.div>
              )}
          </AnimatePresence>

          {!result && !loading && (
              <div className="py-20 flex flex-col items-center justify-center text-center opacity-50">
                  <div className="flex gap-2">
                     <ImageIcon size={64} className="mb-4 text-indigo-300" />
                     <Sparkles size={32} className="mb-4 text-indigo-200 -ml-4 -mt-2" />
                  </div>
                  <p className="text-lg font-medium max-w-sm">Enter a concept and I'll generate an educational picture for you!</p>
              </div>
          )}
      </div>
    </div>
  )
}
