import React from 'react';
import { useStore } from '../../store';
import { motion } from 'motion/react';
import { BrainCircuit, MessageSquare, BookA, AlignLeft, Layers, Image as ImageIcon } from 'lucide-react';
import { cn } from '../../lib/utils';

export default function Dashboard({ onNavigate }: { onNavigate: (screen: string) => void }) {
  const { user } = useStore();
  
  if (!user) return null;

  const isYoung = ['KG', '1', '2', '3', '4', '5'].includes(user.gradeLevel);
  const greetingText = isYoung ? `Hey ${user.name}! Ready to play and learn? 🎈` : `Welcome back, ${user.name}. Let's get to work.`;

  const features = [
    { id: 'quiz', title: 'Quiz Mode', desc: 'Test your knowledge', icon: <BrainCircuit size={28} />, color: 'bg-blue-500 text-white', light: 'bg-blue-50 text-blue-600' },
    { id: 'doubt', title: 'AI Tutor', desc: 'Ask me anything', icon: <MessageSquare size={28} />, color: 'bg-orange-500 text-white', light: 'bg-orange-50 text-orange-600' },
    { id: 'dictionary', title: 'Dictionary', desc: 'Find word meanings', icon: <BookA size={28} />, color: 'bg-emerald-500 text-white', light: 'bg-emerald-50 text-emerald-600' },
    { id: 'summarizer', title: 'Summarizer', desc: 'Make long text short', icon: <AlignLeft size={28} />, color: 'bg-purple-500 text-white', light: 'bg-purple-50 text-purple-600' },
    { id: 'flashcard', title: 'Flashcards', desc: 'Swipe to remember', icon: <Layers size={28} />, color: 'bg-rose-500 text-white', light: 'bg-rose-50 text-rose-600' },
    { id: 'image', title: 'Visualizer', desc: 'Generate images', icon: <ImageIcon size={28} />, color: 'bg-indigo-500 text-white', light: 'bg-indigo-50 text-indigo-600' },
  ];

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Welcome Section */}
      <section className="mt-4">
        <motion.h2 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-2xl sm:text-4xl font-extrabold tracking-tight"
        >
            {greetingText}
        </motion.h2>
        <motion.p 
             initial={{ opacity: 0, x: -20 }}
             animate={{ opacity: 1, x: 0 }}
             transition={{ delay: 0.1 }}
             className="text-gray-500 mt-2 text-sm sm:text-base font-medium"
        >
             Grade {user.gradeLevel} • {user.subjects.slice(0, 3).join(', ')}{user.subjects.length > 3 ? '...' : ''}
        </motion.p>
      </section>

      {/* Badges Overview */}
      {user.badges.length > 0 && (
          <section>
              <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-3 hover:text-gray-600 transition-colors">Your Trophies</h3>
              <div className="flex gap-2 overflow-x-auto pb-2">
                  {user.badges.map((badge, idx) => (
                      <motion.div 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: idx * 0.1 }}
                        key={badge} 
                        className="flex-shrink-0 bg-white border border-gray-100 rounded-full px-4 py-2 text-sm font-medium shadow-sm flex items-center gap-2"
                      >
                          🎖️ {badge}
                      </motion.div>
                  ))}
              </div>
          </section>
      )}

      {/* Features Grid */}
      <section>
        <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-4 hover:text-gray-600 transition-colors">Study Tools</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {features.map((feat, idx) => (
                <motion.button
                    key={feat.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    whileHover={{ y: -4, scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => onNavigate(feat.id)}
                    className="bg-white p-4 sm:p-5 rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100/50 flex flex-col items-start gap-4 text-left group transition-all"
                >
                    <div className={cn("p-3 sm:p-4 rounded-2xl transition-colors", feat.light, "group-hover:" + feat.color, "group-hover:text-white")}>
                        {feat.icon}
                    </div>
                    <div>
                        <h4 className="font-bold text-gray-900 leading-tight mb-1">{feat.title}</h4>
                        <p className="text-xs sm:text-sm text-gray-500 leading-snug">{feat.desc}</p>
                    </div>
                </motion.button>
            ))}
        </div>
      </section>
    </div>
  )
}
