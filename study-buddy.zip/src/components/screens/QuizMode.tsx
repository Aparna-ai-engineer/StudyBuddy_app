import React, { useState } from 'react';
import { useStore } from '../../store';
import { generateQuiz, QuizQuestion } from '../../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, CheckCircle2, XCircle, Brain, Loader2 } from 'lucide-react';
import { cn } from '../../lib/utils';
import ReactMarkdown from 'react-markdown';

export default function QuizMode({ onBack }: { onBack: () => void }) {
  const { user, addXp, addBadge } = useStore();
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [quiz, setQuiz] = useState<QuizQuestion[] | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  // fill in the blank state (as string)
  const [textAnswer, setTextAnswer] = useState('');

  const gradeLevel = user?.gradeLevel || '5';

  const handleCreate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    try {
        const q = await generateQuiz(topic, gradeLevel, 5);
        setQuiz(q);
        setCurrentIdx(0);
        setScore(0);
        setShowResult(false);
    } catch (e) {
        alert("Oops, couldn't generate the quiz. Try again!");
    } finally {
        setLoading(false);
    }
  };

  const handleAnswer = (answer: string) => {
    if (showResult) return;
    setSelectedAnswer(answer);
    
    // We assume exact match for now (or case insensitive for text)
    const isCorrect = answer.toLowerCase().trim() === quiz![currentIdx].correctAnswer.toLowerCase().trim();
    if (isCorrect) {
        setScore(s => s + 1);
        addXp(10);
    }
    setShowResult(true);
  };

  const nextQuestion = () => {
    if (currentIdx < (quiz?.length || 0) - 1) {
        setCurrentIdx(i => i + 1);
        setSelectedAnswer(null);
        setTextAnswer('');
        setShowResult(false);
    } else {
        // Quiz complete
        if (score === quiz?.length) {
            addBadge('Quiz Master 🧠');
            addXp(50);
        }
        setQuiz(null); // return to start
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-4 mb-6">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors">
              <ArrowLeft size={20} className="text-gray-600"/>
          </button>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
              <Brain className="text-blue-500" /> Quiz Mode
          </h2>
      </div>

      {!quiz && (
          <div className="flex-1 bg-white rounded-[2rem] shadow-sm border border-gray-100 p-6 sm:p-10 flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-500 mb-6">
                  <Brain size={40} />
              </div>
              <h3 className="text-2xl font-bold mb-2">What do you want to test?</h3>
              <p className="text-gray-500 mb-8 max-w-md">Enter a topic and I will generate a custom quiz just for you!</p>
              
              <div className="w-full max-w-md flex flex-col gap-3">
                  <input 
                      type="text" 
                      value={topic}
                      onChange={e => setTopic(e.target.value)}
                      placeholder="e.g. Solar System, Fractions, Dinosaurs"
                      className="w-full text-lg px-5 py-4 rounded-xl border border-gray-200 focus:border-blue-500 outline-none transition-all"
                  />
                  <button 
                      onClick={handleCreate}
                      disabled={loading || !topic.trim()}
                      className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold shadow-md hover:bg-blue-700 disabled:opacity-50 transition-colors flex justify-center items-center gap-2"
                  >
                      {loading ? <Loader2 className="animate-spin" /> : "Generate Quiz"}
                  </button>
              </div>
          </div>
      )}

      {quiz && !loading && (
          <div className="flex-1 flex flex-col">
              <div className="flex justify-between items-center mb-4 text-sm font-bold text-gray-500 uppercase tracking-wider">
                  <span>Question {currentIdx + 1} of {quiz.length}</span>
                  <span className="text-blue-600">Score: {score}</span>
              </div>
              
              {/* Progress bar */}
              <div className="w-full h-2 bg-gray-200 rounded-full mb-8 overflow-hidden">
                  <motion.div 
                    className="h-full bg-blue-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentIdx) / quiz.length) * 100}%` }}
                  />
              </div>

              <AnimatePresence mode="wait">
                  <motion.div 
                    key={currentIdx}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="flex-1 flex flex-col items-center"
                  >
                      <h3 className="text-2xl sm:text-3xl font-bold text-center text-gray-900 mb-8 max-w-2xl leading-tight">
                          {quiz[currentIdx].question}
                      </h3>

                      <div className="w-full max-w-xl flex flex-col gap-3 mb-8">
                          {quiz[currentIdx].type === 'mcq' && quiz[currentIdx].options?.map((opt, i) => {
                              const isSelected = selectedAnswer === opt;
                              const isCorrectAnswer = opt === quiz[currentIdx].correctAnswer;
                              
                              let btnClass = "bg-white border-gray-200 text-gray-800 hover:border-blue-300";
                              if (showResult) {
                                  if (isCorrectAnswer) btnClass = "bg-green-100 border-green-500 text-green-800";
                                  else if (isSelected) btnClass = "bg-red-100 border-red-500 text-red-800";
                                  else btnClass = "bg-white border-gray-100 opacity-50";
                              }

                              return (
                                  <button 
                                      key={i}
                                      onClick={() => handleAnswer(opt)}
                                      disabled={showResult}
                                      className={cn(
                                          "w-full p-4 sm:p-5 rounded-2xl border-2 text-left font-medium text-lg transition-all flex justify-between items-center",
                                          btnClass
                                      )}
                                  >
                                      <span>{opt}</span>
                                      {showResult && isCorrectAnswer && <CheckCircle2 className="text-green-600" />}
                                      {showResult && isSelected && !isCorrectAnswer && <XCircle className="text-red-600" />}
                                  </button>
                              )
                          })}

                          {quiz[currentIdx].type === 'tf' && ['True', 'False'].map((opt, i) => {
                               const isSelected = selectedAnswer === opt;
                               const isCorrectAnswer = (quiz[currentIdx].correctAnswer.toLowerCase() === 'true' && opt === 'True') || 
                                                       (quiz[currentIdx].correctAnswer.toLowerCase() === 'false' && opt === 'False');
                               
                               let btnClass = "bg-white border-gray-200 text-gray-800 hover:border-blue-300";
                               if (showResult) {
                                   if (isCorrectAnswer) btnClass = "bg-green-100 border-green-500 text-green-800";
                                   else if (isSelected) btnClass = "bg-red-100 border-red-500 text-red-800";
                                   else btnClass = "bg-white border-gray-100 opacity-50";
                               }
 
                               return (
                                   <button 
                                       key={i}
                                       onClick={() => handleAnswer(opt)}
                                       disabled={showResult}
                                       className={cn(
                                           "w-full p-4 sm:p-5 rounded-2xl border-2 text-center font-bold text-lg transition-all flex justify-center items-center gap-2",
                                           btnClass
                                       )}
                                   >
                                       <span>{opt}</span>
                                       {showResult && isCorrectAnswer && <CheckCircle2 className="text-green-600" />}
                                       {showResult && isSelected && !isCorrectAnswer && <XCircle className="text-red-600" />}
                                   </button>
                               )
                          })}

                          {quiz[currentIdx].type === 'fill' && (
                              <div className="w-full flex gap-2">
                                  <input 
                                      type="text" 
                                      value={textAnswer}
                                      onChange={e => setTextAnswer(e.target.value)}
                                      disabled={showResult}
                                      placeholder="Type your answer..."
                                      className="flex-1 text-lg px-5 py-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 outline-none transition-all disabled:opacity-50 disabled:bg-gray-50 bg-white"
                                  />
                                  {!showResult && (
                                     <button 
                                        onClick={() => handleAnswer(textAnswer)}
                                        className="px-6 py-4 bg-blue-600 text-white font-bold rounded-xl"
                                     >Submit</button> 
                                  )}
                              </div>
                          )}
                      </div>

                      {showResult && (
                          <motion.div 
                              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                              className={cn(
                                  "w-full max-w-xl p-5 rounded-2xl text-center mb-8",
                                  selectedAnswer?.toLowerCase().trim() === quiz[currentIdx].correctAnswer.toLowerCase().trim() ? "bg-green-50 text-green-800" : "bg-orange-50 text-orange-800"
                              )}
                          >
                              <p className="font-bold mb-1">
                                 {selectedAnswer?.toLowerCase().trim() === quiz[currentIdx].correctAnswer.toLowerCase().trim() ? 'Great job! 🎉' : `Not quite! The correct answer is: ${quiz[currentIdx].correctAnswer}`}
                              </p>
                              <div className="text-sm opacity-90"><ReactMarkdown>{quiz[currentIdx].explanation}</ReactMarkdown></div>
                          </motion.div>
                      )}

                      {showResult && (
                          <button 
                              onClick={nextQuestion}
                              className="w-full max-w-xl py-4 bg-gray-900 text-white rounded-xl font-bold shadow-md hover:bg-black transition-colors"
                          >
                              {currentIdx < quiz.length - 1 ? 'Next Question' : 'Finish Quiz'}
                          </button>
                      )}
                  </motion.div>
              </AnimatePresence>
          </div>
      )}
    </div>
  )
}
