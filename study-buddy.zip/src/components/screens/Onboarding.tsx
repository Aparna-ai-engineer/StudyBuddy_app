import React, { useState } from 'react';
import { useStore, GradeLevel } from '../../store';
import { motion } from 'motion/react';
import { cn } from '../../lib/utils';
import { Sparkles, ArrowRight, Check } from 'lucide-react';

const GRADES: { label: string; value: GradeLevel }[] = [
    { label: 'Kindergarten', value: 'KG' },
    { label: 'Grade 1', value: '1' },
    { label: 'Grade 2', value: '2' },
    { label: 'Grade 3', value: '3' },
    { label: 'Grade 4', value: '4' },
    { label: 'Grade 5', value: '5' },
    { label: 'Grade 6', value: '6' },
    { label: 'Grade 7', value: '7' },
    { label: 'Grade 8', value: '8' },
    { label: 'Grade 9', value: '9' },
    { label: 'Grade 10', value: '10' },
    { label: 'Grade 11', value: '11' },
    { label: 'Grade 12', value: '12' },
];

const SUBJECTS = [
    'Math', 'Science', 'English', 'History', 'Geography', 'Art', 'Computer Science', 'Physics', 'Chemistry', 'Biology'
];

export default function Onboarding() {
  const setUser = useStore((state) => state.setUser);
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [grade, setGrade] = useState<GradeLevel | null>(null);
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);

  const handleNext = () => {
    if (step === 1 && name.trim()) setStep(2);
    else if (step === 2 && grade) setStep(3);
    else if (step === 3 && selectedSubjects.length > 0) {
        setUser({
            name,
            gradeLevel: grade!,
            subjects: selectedSubjects,
            xp: 0,
            streak: 1,
            badges: ['Early Bird']
        });
    }
  };

  const toggleSubject = (sub: string) => {
    if (selectedSubjects.includes(sub)) {
        setSelectedSubjects(s => s.filter(x => x !== sub));
    } else {
        setSelectedSubjects(s => [...s, sub]);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] flex items-center justify-center p-4">
        <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl shadow-xl overflow-hidden max-w-md w-full relative"
        >
            <div className="absolute top-0 left-0 w-full h-2 bg-gray-100">
                <motion.div 
                    className="h-full bg-orange-500"
                    initial={{ width: '33%' }}
                    animate={{ width: `${(step / 3) * 100}%` }}
                />
            </div>

            <div className="p-8 pt-12">
                {step === 1 && (
                    <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
                        <div className="w-16 h-16 bg-orange-100 text-orange-500 rounded-2xl flex items-center justify-center mb-6">
                            <Sparkles size={32} />
                        </div>
                        <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome to StudyBuddy!</h2>
                        <p className="text-gray-500 mb-8">Your personal AI tutor. Let's get to know you first.</p>
                        
                        <div className="mb-6">
                            <label className="block text-sm font-medium text-gray-700 mb-2">What should I call you?</label>
                            <input 
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="E.g. Alex"
                                className="w-full text-lg px-4 py-3 rounded-xl border border-gray-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none transition-all"
                                autoFocus
                                onKeyDown={(e) => e.key === 'Enter' && handleNext()}
                            />
                        </div>
                    </motion.div>
                )}

                {step === 2 && (
                    <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">Nice to meet you, {name}!</h2>
                        <p className="text-gray-500 mb-6">What grade are you currently in? This helps me adjust my teaching style.</p>
                        
                        <div className="grid grid-cols-3 gap-2 h-64 overflow-y-auto p-1 pb-4">
                            {GRADES.map(g => (
                                <button
                                    key={g.value}
                                    onClick={() => setGrade(g.value)}
                                    className={cn(
                                        "py-3 px-2 rounded-xl border text-sm font-medium transition-all duration-200",
                                        grade === g.value 
                                            ? "border-orange-500 bg-orange-50 text-orange-700 shadow-sm scale-95" 
                                            : "border-gray-200 hover:border-orange-300 hover:bg-orange-50/50 text-gray-600"
                                    )}
                                >
                                    {g.label}
                                </button>
                            ))}
                        </div>
                    </motion.div>
                )}

                {step === 3 && (
                    <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">What do you want to learn?</h2>
                        <p className="text-gray-500 mb-6">Pick a few subjects you want help with. You can change this later.</p>
                        
                        <div className="flex flex-wrap gap-2 mb-8">
                            {SUBJECTS.map(sub => {
                                const isSelected = selectedSubjects.includes(sub);
                                return (
                                    <button
                                        key={sub}
                                        onClick={() => toggleSubject(sub)}
                                        className={cn(
                                            "flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-medium transition-all",
                                            isSelected 
                                                ? "bg-gray-900 border-gray-900 text-white" 
                                                : "bg-white border-gray-200 text-gray-600 hover:border-gray-400"
                                        )}
                                    >
                                        {isSelected && <Check size={14} />}
                                        {sub}
                                    </button>
                                )
                            })}
                        </div>
                    </motion.div>
                )}

                <div className="mt-8">
                    <button 
                        onClick={handleNext}
                        disabled={
                            (step === 1 && !name.trim()) || 
                            (step === 2 && !grade) || 
                            (step === 3 && selectedSubjects.length === 0)
                        }
                        className="w-full bg-gray-900 hover:bg-gray-800 disabled:bg-gray-200 disabled:text-gray-400 text-white font-semibold py-4 rounded-xl flex items-center justify-center gap-2 transition-colors"
                    >
                        {step === 3 ? "Let's Go!" : "Continue"}
                        {step !== 3 && <ArrowRight size={20} />}
                    </button>
                </div>
            </div>
        </motion.div>
    </div>
  )
}
