import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../../store';
import { solveDoubt } from '../../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Send, Sparkles, User, Loader2 } from 'lucide-react';
import { cn } from '../../lib/utils';
import ReactMarkdown from 'react-markdown';

interface ChatMessage {
    id: string;
    role: 'user' | 'ai';
    content: string;
}

export default function DoubtSolver({ onBack }: { onBack: () => void }) {
  const { user, addXp } = useStore();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const gradeLevel = user?.gradeLevel || '5';

  useEffect(() => {
     // Initial greeting
     setMessages([
         { id: 'start', role: 'ai', content: `Hi ${user?.name}! 😊 I'm your AI StudyBuddy. What do you need help with today?` }
     ]);
  }, []);

  useEffect(() => {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
      if (!input.trim() || loading) return;
      const userMsg = input.trim();
      setInput('');
      
      const newMsgs: ChatMessage[] = [...messages, { id: Date.now().toString(), role: 'user', content: userMsg }];
      setMessages(newMsgs);
      setLoading(true);

      try {
          // get recent context (last few msgs)
          const context = newMsgs.slice(-4).map(m => `${m.role}: ${m.content}`).join('\n');
          const aiResponse = await solveDoubt(userMsg, gradeLevel, context);
          
          setMessages(m => [...m, { id: Date.now().toString(), role: 'ai', content: aiResponse }]);
          addXp(2); // small reward for asking questions
      } catch (e) {
          setMessages(m => [...m, { id: Date.now().toString(), role: 'ai', content: "Uh oh, something went wrong. Let's try again!" }]);
      } finally {
          setLoading(false);
      }
  };

  return (
    <div className="flex flex-col h-full absolute inset-0">
      <div className="flex items-center gap-4 p-4 border-b border-gray-100 bg-white/50 backdrop-blur-md sticky top-0 z-10">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors">
              <ArrowLeft size={20} className="text-gray-600"/>
          </button>
          <div>
              <h2 className="text-xl font-bold flex items-center gap-2 text-gray-900">
                  <Sparkles className="text-orange-500" /> AI Tutor
              </h2>
              <p className="text-xs text-gray-500">Ask me anything about your studies</p>
          </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 pb-32">
          <AnimatePresence initial={false}>
              {messages.map(msg => (
                  <motion.div 
                      key={msg.id}
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      className={cn(
                          "flex w-full gap-3",
                          msg.role === 'user' ? "justify-end" : "justify-start"
                      )}
                  >
                      {msg.role === 'ai' && (
                          <div className="w-8 h-8 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center flex-shrink-0 mt-1">
                              <Sparkles size={16} />
                          </div>
                      )}
                      
                      <div className={cn(
                          "max-w-[80%] px-5 py-3 rounded-2xl",
                          msg.role === 'user' 
                              ? "bg-gray-900 text-white rounded-tr-sm" 
                              : "bg-white border border-gray-100 shadow-sm text-gray-800 rounded-tl-sm markdown-body text-sm sm:text-base leading-relaxed"
                      )}>
                          {msg.role === 'user' ? msg.content : <ReactMarkdown>{msg.content}</ReactMarkdown>}
                      </div>
                  </motion.div>
              ))}
              
              {loading && (
                   <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex w-full gap-3 justify-start"
                  >
                      <div className="w-8 h-8 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center flex-shrink-0">
                          <Loader2 size={16} className="animate-spin" />
                      </div>
                      <div className="px-5 py-3 rounded-2xl bg-white border border-gray-100 shadow-sm text-gray-400 rounded-tl-sm flex items-center gap-1">
                          <span className="animate-bounce">.</span>
                          <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>.</span>
                          <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>.</span>
                      </div>
                  </motion.div>
              )}
          </AnimatePresence>
          <div ref={bottomRef} className="h-4" />
      </div>

      <div className="absolute bottom-[80px] sm:bottom-0 left-0 w-full p-4 bg-gradient-to-t from-white via-white to-transparent pt-10">
          <div className="max-w-3xl mx-auto flex gap-2 w-full relative">
              <input 
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                  placeholder="Type your question..."
                  className="flex-1 bg-white border border-gray-200 rounded-full px-5 py-4 focus:outline-none focus:border-orange-500 shadow-sm text-gray-900"
              />
              <button 
                  onClick={handleSend}
                  disabled={!input.trim() || loading}
                  className="w-14 h-14 bg-orange-500 rounded-full flex items-center justify-center text-white shadow-md hover:bg-orange-600 focus:outline-none disabled:opacity-50 transition-colors"
              >
                  <Send size={20} className="ml-1" />
              </button>
          </div>
      </div>
    </div>
  )
}
