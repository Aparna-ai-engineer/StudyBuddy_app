import React, { useState } from 'react';
import { useStore } from '../../store';
import { generateFlashcards } from '../../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Layers, Sparkles, Loader2, RotateCw, ArrowRight } from 'lucide-react';
import { cn } from '../../lib/utils';

export default function FlashcardMode({ onBack }: { onBack: () => void }) {
  const { user, addXp } = useStore();
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [cards, setCards] = useState<{front: string, back: string}[] | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const gradeLevel = user?.gradeLevel || '5';

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setCards(null);
    try {
        const res = await generateFlashcards(topic, gradeLevel, 5);
        if (res && res.length > 0) {
            setCards(res);
            setCurrentIdx(0);
            setIsFlipped(false);
        } else {
             alert("Failed to generate cards.");
        }
    } catch (e) {
        alert("Oops, couldn't generate. Try again!");
    } finally {
        setLoading(false);
    }
  };

  const nextCard = () => {
      if (cards && currentIdx < cards.length - 1) {
          setIsFlipped(false);
          setTimeout(() => setCurrentIdx(i => i + 1), 150);
      } else {
          addXp(20);
          setCards(null);
      }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-4 mb-6">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors">
              <ArrowLeft size={20} className="text-gray-600"/>
          </button>
          <h2 className="text-xl font-bold flex items-center gap-2">
              <Layers className="text-rose-500" /> Flashcards
          </h2>
      </div>

      {!cards && (
          <div className="flex-1 bg-white rounded-[2rem] shadow-sm border border-gray-100 p-6 sm:p-10 flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-500 mb-6">
                  <Layers size={40} />
              </div>
              <h3 className="text-2xl font-bold mb-2">What are you reviewing?</h3>
              <p className="text-gray-500 mb-8 max-w-md">I'll create custom flashcards so you can test your memory.</p>
              
              <div className="w-full max-w-md flex flex-col gap-3">
                  <input 
                      type="text" 
                      value={topic}
                      onChange={e => setTopic(e.target.value)}
                      placeholder="e.g. World War II, Periodic Table"
                      className="w-full text-lg px-5 py-4 rounded-xl border border-gray-200 focus:border-rose-500 outline-none transition-all"
                  />
                  <button 
                      onClick={handleGenerate}
                      disabled={loading || !topic.trim()}
                      className="w-full py-4 bg-rose-500 text-white rounded-xl font-bold shadow-md hover:bg-rose-600 disabled:opacity-50 transition-colors flex justify-center items-center gap-2"
                  >
                      {loading ? <Loader2 className="animate-spin" /> : <><Sparkles size={18}/> Make Flashcards</>}
                  </button>
              </div>
          </div>
      )}

      {cards && !loading && (
          <div className="flex-1 flex flex-col items-center justify-center pb-20 relative">
              <div className="absolute top-0 right-0 left-0 flex justify-center mt-2">
                 <span className="text-sm font-bold text-gray-400 bg-white px-3 py-1 rounded-full shadow-sm">Card {currentIdx + 1} of {cards.length}</span>
              </div>

              <div className="w-full max-w-md h-80 sm:h-96 relative perspective-1000" onClick={() => setIsFlipped(!isFlipped)}>
                  <motion.div 
                      className="w-full h-full relative preserve-3d cursor-pointer"
                      animate={{ rotateY: isFlipped ? 180 : 0 }}
                      transition={{ duration: 0.6, type: "spring", stiffness: 200, damping: 20 }}
                  >
                      {/* FRONT */}
                      <div className="absolute w-full h-full backface-hidden bg-white border-2 border-rose-100 shadow-[0_10px_40px_rgb(0,0,0,0.08)] rounded-[2.5rem] p-8 flex flex-col items-center justify-center text-center group">
                          <span className="absolute top-6 left-6 text-xs font-bold text-rose-300 uppercase letter-spacing-wider">Question</span>
                          <h3 className="text-3xl font-extrabold text-gray-800 break-words">{cards[currentIdx].front}</h3>
                          <div className="absolute bottom-6 flex items-center justify-center gap-2 text-rose-300 group-hover:text-rose-400 transition-colors">
                              <RotateCw size={16} /> <span className="text-sm font-semibold">Tap to flip</span>
                          </div>
                      </div>

                      {/* BACK */}
                      <div className="absolute w-full h-full backface-hidden rotate-y-180 bg-rose-500 border-2 border-rose-600 shadow-[20px_10px_40px_rgba(244,63,94,0.2)] rounded-[2.5rem] p-8 flex flex-col items-center justify-center text-center text-white">
                           <span className="absolute top-6 left-6 text-xs font-bold text-rose-200 uppercase letter-spacing-wider">Answer</span>
                           <h3 className="text-2xl sm:text-3xl font-bold break-words">{cards[currentIdx].back}</h3>
                      </div>
                  </motion.div>
              </div>

              <div className="mt-12 w-full max-w-md flex justify-center">
                  <AnimatePresence>
                     {isFlipped && (
                          <motion.button 
                              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                              onClick={(e) => { e.stopPropagation(); nextCard(); }}
                              className="w-full py-4 bg-gray-900 text-white rounded-xl font-bold shadow-md hover:bg-black transition-colors flex justify-center items-center gap-2"
                          >
                              {currentIdx < cards.length - 1 ? 'Next Card' : 'Finish Deck'} <ArrowRight size={20} />
                          </motion.button>
                     )}
                  </AnimatePresence>
              </div>
          </div>
      )}
    </div>
  )
}
