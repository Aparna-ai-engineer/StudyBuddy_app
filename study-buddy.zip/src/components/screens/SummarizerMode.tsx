import React, { useState } from 'react';
import { useStore } from '../../store';
import { summarizeText } from '../../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, AlignLeft, Sparkles, Loader2, Copy } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function SummarizerMode({ onBack }: { onBack: () => void }) {
  const { user, addXp } = useStore();
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const gradeLevel = user?.gradeLevel || '5';

  const handleSummarize = async () => {
    if (!text.trim() || text.length < 20) {
        alert("Please paste a bit more text for me to summarize!");
        return;
    }
    setLoading(true);
    setResult(null);
    try {
        const res = await summarizeText(text, gradeLevel);
        setResult(res);
        addXp(5);
    } catch (e) {
        alert("Could not summarize. Please try again.");
    } finally {
        setLoading(false);
    }
  };

  const copyToClipboard = () => {
      if (result) navigator.clipboard.writeText(result);
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-4 mb-6">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors">
              <ArrowLeft size={20} className="text-gray-600"/>
          </button>
          <h2 className="text-xl font-bold flex items-center gap-2">
              <AlignLeft className="text-purple-500" /> Summarizer
          </h2>
      </div>

      <div className="grid md:grid-cols-2 gap-6 h-full pb-10">
          <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 p-6 flex flex-col h-full md:min-h-[60vh]">
              <h3 className="font-bold mb-4 flex items-center gap-2"><AlignLeft size={18} /> Original Text</h3>
              <textarea 
                  value={text}
                  onChange={e => setText(e.target.value)}
                  placeholder="Paste your long textbook paragraph, article, or notes here..."
                  className="flex-1 w-full p-4 rounded-xl border border-gray-200 focus:border-purple-500 outline-none resize-none mb-4"
              />
              <button 
                  onClick={handleSummarize}
                  disabled={loading || text.length < 10}
                  className="w-full py-4 bg-purple-600 text-white font-bold rounded-xl shadow-md hover:bg-purple-700 disabled:opacity-50 transition-colors flex justify-center items-center gap-2"
              >
                  {loading ? <Loader2 className="animate-spin" /> : <><Sparkles size={18}/> Summarize It!</>}
              </button>
          </div>

          <div className="bg-purple-50 rounded-[2rem] border border-purple-100 p-6 flex flex-col relative h-full md:min-h-[60vh]">
               <h3 className="font-bold mb-4 flex items-center gap-2 text-purple-900"><Sparkles size={18} className="text-purple-500" /> AI Summary</h3>
               <div className="flex-1 overflow-y-auto w-full">
                   <AnimatePresence mode="wait">
                       {!result && !loading && (
                           <motion.div initial={{opacity:0}} animate={{opacity:1}} className="h-full flex items-center justify-center text-purple-300">
                               <p className="font-medium text-center">Your magical summary will appear here.</p>
                           </motion.div>
                       )}
                       {loading && (
                           <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="h-full flex items-center justify-center text-purple-400">
                               <Loader2 size={32} className="animate-spin" />
                           </motion.div>
                       )}
                       {result && (
                           <motion.div initial={{opacity:0, y: 10}} animate={{opacity:1, y:0}} className="prose prose-purple max-w-none text-gray-800 bg-white p-6 rounded-2xl shadow-sm border border-purple-100/50">
                               <ReactMarkdown>{result}</ReactMarkdown>
                           </motion.div>
                       )}
                   </AnimatePresence>
               </div>
               
               {result && (
                   <button onClick={copyToClipboard} className="absolute top-6 right-6 p-2 bg-white text-purple-600 rounded-lg shadow-sm hover:bg-purple-100 transition-colors" title="Copy to clipboard">
                       <Copy size={20} />
                   </button>
               )}
          </div>
      </div>
    </div>
  )
}
