import React, { useState } from 'react';
import { useStore } from '../../store';
import { getDictionaryMeaning } from '../../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, BookA, Search, Volume2, Loader2 } from 'lucide-react';

export default function DictionaryMode({ onBack }: { onBack: () => void }) {
  const { user, addXp } = useStore();
  const [word, setWord] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{definition: string, example: string, partOfSpeech: string} | null>(null);

  const gradeLevel = user?.gradeLevel || '5';

  const handleSearch = async () => {
    if (!word.trim()) return;
    setLoading(true);
    setResult(null);
    try {
        const res = await getDictionaryMeaning(word, gradeLevel);
        setResult(res);
        addXp(1);
    } catch (e) {
        alert("Couldn't find that word. Try checking spelling!");
    } finally {
        setLoading(false);
    }
  };

  const speakText = (text: string) => {
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-4 mb-6">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors">
              <ArrowLeft size={20} className="text-gray-600"/>
          </button>
          <h2 className="text-xl font-bold flex items-center gap-2">
              <BookA className="text-emerald-500" /> Dictionary
          </h2>
      </div>

      <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 p-6 sm:p-10 flex flex-col items-center">
          <div className="w-full max-w-lg mb-8 relative">
              <input 
                  type="text" 
                  value={word}
                  onChange={e => setWord(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSearch()}
                  placeholder="Type a word..."
                  className="w-full text-lg px-6 py-4 pl-14 rounded-2xl border-2 border-emerald-100 focus:border-emerald-500 outline-none transition-all bg-emerald-50/30"
              />
              <Search className="absolute left-5 top-5 text-emerald-400" size={24} />
              
              <button 
                  onClick={handleSearch}
                  disabled={loading || !word.trim()}
                  className="absolute right-3 top-3 bottom-3 px-6 bg-emerald-500 text-white font-bold rounded-xl shadow-sm hover:bg-emerald-600 disabled:opacity-50 transition-colors"
              >
                  {loading ? <Loader2 size={20} className="animate-spin" /> : "Look up"}
              </button>
          </div>

          <AnimatePresence mode="wait">
              {result && (
                  <motion.div 
                      key={word}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="w-full max-w-lg bg-emerald-50 rounded-3xl p-8 border border-emerald-100"
                  >
                      <div className="flex items-center justify-between mb-2">
                          <h3 className="text-4xl font-extrabold text-emerald-900 capitalize tracking-tight">{word}</h3>
                          <button onClick={() => speakText(word)} className="p-3 bg-white text-emerald-600 rounded-full shadow-sm hover:scale-105 transition-transform"><Volume2 size={24} /></button>
                      </div>
                      <span className="inline-block px-3 py-1 bg-emerald-200/50 text-emerald-800 text-xs font-bold uppercase tracking-widest rounded-md mb-6 relative -top-1">
                          {result.partOfSpeech}
                      </span>
                      
                      <div className="space-y-6">
                          <div>
                              <h4 className="text-sm font-bold text-emerald-800 mb-1">Definition</h4>
                              <p className="text-lg text-gray-800 leading-relaxed font-medium">{result.definition}</p>
                          </div>
                           <div>
                              <h4 className="text-sm font-bold text-emerald-800 mb-1">Example</h4>
                              <p className="text-lg text-gray-600 italic">"{result.example}"</p>
                          </div>
                      </div>
                  </motion.div>
              )}
          </AnimatePresence>

          {!result && !loading && (
              <div className="py-20 flex flex-col items-center justify-center text-center opacity-50">
                  <BookA size={64} className="mb-4 text-emerald-300" />
                  <p className="text-lg font-medium">Search for any word to learn its meaning!</p>
              </div>
          )}
      </div>
    </div>
  )
}
