import React, { useState } from 'react';
import { useStore } from './store';
import Onboarding from './components/screens/Onboarding';
import Dashboard from './components/screens/Dashboard';
import QuizMode from './components/screens/QuizMode';
import DoubtSolver from './components/screens/DoubtSolver';
import DictionaryMode from './components/screens/DictionaryMode';
import SummarizerMode from './components/screens/SummarizerMode';
import FlashcardMode from './components/screens/FlashcardMode';
import ImageGeneratorMode from './components/screens/ImageGeneratorMode';
import Layout from './components/Layout';

export type Screen = 'dashboard' | 'quiz' | 'doubt' | 'dictionary' | 'summarizer' | 'flashcard' | 'image';

export default function App() {
  const { isOnboarded } = useStore();
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');

  if (!isOnboarded) {
    return <Onboarding />;
  }

  const navigate = (s: string) => setCurrentScreen(s as Screen);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard': return <Dashboard onNavigate={navigate} />;
      case 'quiz': return <QuizMode onBack={() => setCurrentScreen('dashboard')} />;
      case 'doubt': return <DoubtSolver onBack={() => setCurrentScreen('dashboard')} />;
      case 'dictionary': return <DictionaryMode onBack={() => setCurrentScreen('dashboard')} />;
      case 'summarizer': return <SummarizerMode onBack={() => setCurrentScreen('dashboard')} />;
      case 'flashcard': return <FlashcardMode onBack={() => setCurrentScreen('dashboard')} />;
      case 'image': return <ImageGeneratorMode onBack={() => setCurrentScreen('dashboard')} />;
      default: return <Dashboard onNavigate={navigate} />;
    }
  };

  return (
    <Layout currentScreen={currentScreen} onNavigate={navigate}>
      {renderScreen()}
    </Layout>
  );
}
