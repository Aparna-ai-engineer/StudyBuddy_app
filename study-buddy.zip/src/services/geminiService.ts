import { GoogleGenAI } from '@google/genai';

// Initialize the API client
// Note: In development/AI Studio, the key is typically auto-injected.
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
const model = 'gemini-2.5-flash';

export interface QuizQuestion {
  question: string;
  options?: string[]; // for mcq
  correctAnswer: string;
  type: 'mcq' | 'fill' | 'tf';
  explanation: string;
}

export const generateQuiz = async (topic: string, grade: string, count: number = 3): Promise<QuizQuestion[]> => {
  const prompt = `You are an expert friendly teacher for a student in grade ${grade}.
Generate a quiz about "${topic}" consisting of ${count} questions.
Include a mix of 'mcq' (Multiple Choice), 'fill' (Fill in the blank), and 'tf' (True/False) if appropriate for the grade.
For younger grades (KG-5), keep it simple. For upper grades, make it conceptual.

Respond ONLY with a valid JSON array of objects, where each object matches this structure:
{
  "question": "The question text",
  "type": "mcq" | "fill" | "tf",
  "options": ["opt1", "opt2", "opt3", "opt4"], // only if type is mcq
  "correctAnswer": "The exact correct option or word/phrase",
  "explanation": "Friendly explanation of why it's correct"
}`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });
    
    if (response.text) {
        return JSON.parse(response.text) as QuizQuestion[];
    }
    return [];
  } catch (e) {
    console.error("Error generating quiz:", e);
    throw e;
  }
};

export const solveDoubt = async (doubt: string, grade: string, previousContext: string = ""): Promise<string> => {
  const systemPrompt = `You are an encouraging, friendly AI study mentor for a student in grade ${grade}. 
Explain concepts clearly, using analogies appropriate for their age. Use emojis 😊.
For younger kids, use very simple words. For older users, provide structured conceptual clarity.`;

  const prompt = `${systemPrompt}\n\nCurrent Doubt: ${doubt}\n`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text || "I'm having trouble thinking of an answer right now. Could you ask me again?";
  } catch (e) {
    console.error("Error solving doubt:", e);
    return "Oops! My brain got a little tangled. Can you try asking again?";
  }
};

export const getDictionaryMeaning = async (word: string, grade: string) => {
    const prompt = `Define the word "${word}" for a student in grade ${grade}.
Return ONLY a valid JSON object:
{
    "definition": "Clear, age-appropriate definition",
    "example": "An example sentence using the word",
    "partOfSpeech": "noun/verb/etc"
}`;
    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        if (response.text) {
            return JSON.parse(response.text);
        }
        return null;
    } catch (e) {
        throw new Error("Could not find meaning.");
    }
}

export const summarizeText = async (text: string, grade: string) => {
     const prompt = `Summarize the following text for a grade ${grade} student. 
Make it clean, structured, and easy to understand. Emphasize key points.

Text:
${text}`;
    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
        });
        return response.text;
    } catch (e) {
        throw new Error("Summarization failed.");
    }
}

export const generateFlashcards = async (topic: string, grade: string, count: number = 5) => {
    const prompt = `Create ${count} flashcards about "${topic}" for a grade ${grade} student.
Return ONLY a valid JSON array of objects:
[
  { "front": "Question or term", "back": "Answer or definition" }
]`;
    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        if (response.text) return JSON.parse(response.text);
        return [];
    } catch (e) {
        throw new Error("Failed to generate flashcards.");
    }
}
